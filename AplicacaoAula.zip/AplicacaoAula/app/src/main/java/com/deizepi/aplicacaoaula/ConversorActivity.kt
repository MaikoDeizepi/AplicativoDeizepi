package com.deizepi.aplicacaoaula

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_conversor.*

class ConversorActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_conversor)

        btnCalcular.setOnClickListener {
            val km = txtValor.text.toString().toInt()
            val metros  = km*1000
            val centimetros = metros*100
            val milimitros = centimetros * 10

            txtMetro.text = metros.toString()+"  Metros"
            txtCentimetros.text = centimetros.toString()+"  Centimetros"
            txtMilimetros.text = milimitros.toString()+"  Milimetros"


        }
        btnVoltarKm.setOnClickListener {
            val mIntent = Intent(this, AplicacaoActivity::class.java)
            startActivity(mIntent)
        }
        btnLimparKM.setOnClickListener {
            txtValor.setText("")
            txtMetro.text = ""
            txtCentimetros.text =""
            txtMilimetros.text = ""
        }
    }
}