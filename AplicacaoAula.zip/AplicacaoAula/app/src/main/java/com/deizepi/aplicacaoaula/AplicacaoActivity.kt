package com.deizepi.aplicacaoaula

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_aplicacao.*

class AplicacaoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_aplicacao)

        btnImpar.setOnClickListener {
            val mIntent = Intent(this,ImparOuParActivity::class.java)
            startActivity(mIntent)
        }
        btnAnoBissexto.setOnClickListener {
            val mIntent = Intent(this,AnoBissextoActivity::class.java)
            startActivity(mIntent)
        }
        btnConversor.setOnClickListener {
            val mIntent = Intent(this,ConversorActivity::class.java)
            startActivity(mIntent)
        }

    }
}