package com.deizepi.aplicacaoaula

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import kotlinx.android.synthetic.main.activity_ano_bissexto.*
import kotlinx.android.synthetic.main.activity_aplicacao.*


class AnoBissextoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ano_bissexto)

        btnCalcular.setOnClickListener {
            val valor = txtAno.text.toString().toInt()
            if (valor %4 == 0 || valor /400 ==0){
                txtValor.text = "Ano Bissexto"
            }else{
                txtValor.text = "Este não é um Ano Bissexto"
            }


        }
        btnVoltarAno.setOnClickListener {
            val intent = Intent(this, AplicacaoActivity::class.java)
            startActivity(intent)
        }

        btnLimpar.setOnClickListener {
            txtAno.setText("")
            txtValor.text = ""
        }


    }

}