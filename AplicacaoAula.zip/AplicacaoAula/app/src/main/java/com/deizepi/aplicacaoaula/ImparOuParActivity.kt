package com.deizepi.aplicacaoaula

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_impar_ou_par.*

class ImparOuParActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_impar_ou_par)

        btnCalcular.setOnClickListener {
            val valor = txtNumero.text.toString().toInt()
            if (valor % 2 == 0) {
                txtValor.text = "Valor Par"

            } else {
                txtValor.text = "Valor Impar"

            }


        }
        btnVoltarPar.setOnClickListener {
            val mIntent = Intent(this,AplicacaoActivity::class.java)
            startActivity(mIntent)
        }

        btnLimparPar.setOnClickListener {
            txtNumero.setText("")
            txtValor.text = ""
        }
    }


}